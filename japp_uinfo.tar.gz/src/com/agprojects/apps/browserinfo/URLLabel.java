package com.agprojects.apps.browserinfo;

import java.applet.*;
import java.awt.*;
import java.awt.event.*;
import java.net.*;

public class URLLabel extends Label {

	private static final long serialVersionUID = 6748302203334342515L;
	private java.applet.Applet applet;
	private URL url;
	private String target = "";
	private Color unvisitedURL = Color.blue;
	private Color visitedURL = Color.blue;

	public URLLabel(Applet applet , String url, String text){
		this(applet, url, text, "_self");
	}

	public URLLabel (Applet applet , String url, String text, String target){
		super(text);
		setForeground(unvisitedURL);
		try {
			this.applet = applet;
			this.url = new URL(url);
			this.target = target;
			addMouseListener( new Clicked() );
		}catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void paint(Graphics g) {
		Rectangle r;
		super.paint(g);
		r = g.getClipBounds();
		g.drawLine(0,
				r.height - this.getFontMetrics(this.getFont()).getDescent(),
				this.getFontMetrics(this.getFont()).stringWidth(this.getText()),
				r.height - this.getFontMetrics(this.getFont()).getDescent()
		);
	}

	public void setUnvisitedURLColor(Color c) {
		unvisitedURL = c;
	}

	public void setVisitedURLColor(Color c) {
		visitedURL = c;
	}

	class Clicked extends MouseAdapter{
		public void mouseClicked(MouseEvent me){
			setForeground(visitedURL);
			applet.getAppletContext().showDocument(url, target);
		}
	}

}
